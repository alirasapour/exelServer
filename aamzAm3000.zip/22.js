var fins = require('omron-fins');
var client = fins.FinsClient(9600,'169.254.68.112');


client.on('error',function(error) {
  console.log("Error: ", error);
});


client.on('reply',function(msg) {
  	console.log("Reply from: ", msg.remotehost);
  	console.log("Transaction SID: ", msg.sid)
	console.log("Replying to issued command of: ", msg.command);
	console.log("Response code of: ", msg.code);
	console.log("Data returned: ", msg.values);
});


setInterval(() => {
	console.clear();
	client.read('C000',20);
}, 1000);


// setInterval(() => {
// 	console.clear()
// 	client.readMultiple('I00')
// }, 1500);


// setTimeout(() => {
// 	client.run();
// }, 5600);