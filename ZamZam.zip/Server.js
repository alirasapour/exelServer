var fins = require('omron-fins');
const express = require('express');
const app = express()
const port = 5000
app.set('view engine', 'ejs');
var client = fins.FinsClient(9600,'169.254.68.112');

app.get('/', (req, res) => {
  res.render('./setup.ejs')
})
app.get('/home', (req, res) => {
	res.render('./index.ejs')
  })
// PLC OmRon -> STOP
app.get('/stop', (req, res) => {
	client.stop();
	res.json(1)
  })
// PLC OmRon -> RUN
app.get('/run', (req, res) => {
	client.run();
	res.json(1)
  })
app.listen(port, () => {
  console.log(`ZamZam webApplication listening on port ${port}`)
})


client.on('error',function(error) {
  console.log("Error: ", error);
});

client.on('reply',function(msg) {
  	console.log("Reply from: ", msg.remotehost);
  	console.log("Transaction SID: ", msg.sid)
	console.log("Replying to issued command of: ", msg.command);
	console.log("Response code of: ", msg.code);
	console.log("Data returned: ", msg.values);
});

client.read('H00000',100);


setTimeout(() => {
	client.run();
}, 5600);