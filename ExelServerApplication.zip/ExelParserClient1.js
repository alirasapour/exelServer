var Excel = require('exceljs');
const reader = require('xlsx')
const axios = require('axios').default;

let writeOnCloudInterval = setInterval(() => {
  const file = reader.readFile('./ExelFiles1.xlsx')
  let data = []
  const sheets = file.SheetNames
  for (let i = 0; i < sheets.length; i++) {
    const temp = reader.utils.sheet_to_json(
      file.Sheets[file.SheetNames[i]])
    temp.forEach((res) => {
      data.push(res)
    })
  }
  let r1 = data[0].writeOnCloud;
  let r2 = data[1].writeOnCloud;
  let r3 = data[2].writeOnCloud;
  let r4 = data[3].writeOnCloud;
  let r5 = data[4].writeOnCloud;
  let r6 = data[5].writeOnCloud;
  let r7 = data[6].writeOnCloud;
  let r8 = data[7].writeOnCloud;
  let r9 = data[8].writeOnCloud;
  let r10 = data[9].writeOnCloud;
  let r11 = data[10].writeOnCloud;
  let r12 = data[11].writeOnCloud;
  let r13 = data[12].writeOnCloud;
  let r14 = data[13].writeOnCloud;
  let r15 = data[14].writeOnCloud;
  let r16 = data[15].writeOnCloud;
  let r17 = data[16].writeOnCloud;
  let r18 = data[17].writeOnCloud;
  let r19 = data[18].writeOnCloud;
  let r20 = data[19].writeOnCloud;
  let r21 = data[20].writeOnCloud;
  let r22 = data[21].writeOnCloud;
  let r23 = data[22].writeOnCloud;
  let r24 = data[23].writeOnCloud;
  let r25 = data[24].writeOnCloud;
  let r26 = data[25].writeOnCloud;
  let r27 = data[26].writeOnCloud;
  let r28 = data[27].writeOnCloud;
  let r29 = data[28].writeOnCloud;
  let r30 = data[29].writeOnCloud;
  axios.post('http://localhost:4000/setR', {
    r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27, r28, r29, r30
  })
    .then(function (response) {
      console.clear();
    })
    .catch(function (error) {
      console.log(error);
    });
}, 1450);


// Application.CalculateFullRebuild

// Sub macro_timer()
// 'Tells Excel when to next run the macro.
// Application.OnTime Now + TimeValue("00:00:01"), "my_macro"
// End Sub
// Sub my_macro()
// Application.CalculateFullRebuild
// 'Calls the timer macro so it can be run again at the next interval.
// Call macro_timer
// End Sub