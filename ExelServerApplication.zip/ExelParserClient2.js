var Excel = require('exceljs');
const reader = require('xlsx')
const axios = require('axios').default;

let writeOnCloudInterval = setInterval(() => {
  const file = reader.readFile('./ExelFiles2.xlsx')
  let data = []
  const sheets = file.SheetNames
  for (let i = 0; i < sheets.length; i++) {
    const temp = reader.utils.sheet_to_json(
      file.Sheets[file.SheetNames[i]])
    temp.forEach((res) => {
      data.push(res)
    })
  }
  let w1 = data[0].writeOnCloud;
  let w2 = data[1].writeOnCloud;
  let w3 = data[2].writeOnCloud;
  let w4 = data[3].writeOnCloud;
  let w5 = data[4].writeOnCloud;
  let w6 = data[5].writeOnCloud;
  let w7 = data[6].writeOnCloud;
  let w8 = data[7].writeOnCloud;
  let w9 = data[8].writeOnCloud;
  let w10 = data[9].writeOnCloud;
  let w11 = data[10].writeOnCloud;
  let w12 = data[11].writeOnCloud;
  let w13 = data[12].writeOnCloud;
  let w14 = data[13].writeOnCloud;
  let w15 = data[14].writeOnCloud;
  let w16 = data[15].writeOnCloud;
  let w17 = data[16].writeOnCloud;
  let w18 = data[17].writeOnCloud;
  let w19 = data[18].writeOnCloud;
  let w20 = data[19].writeOnCloud;
  let w21 = data[20].writeOnCloud;
  let w22 = data[21].writeOnCloud;
  let w23 = data[22].writeOnCloud;
  let w24 = data[23].writeOnCloud;
  let w25 = data[24].writeOnCloud;
  let w26 = data[25].writeOnCloud;
  let w27 = data[26].writeOnCloud;
  let w28 = data[27].writeOnCloud;
  let w29 = data[28].writeOnCloud;
  let w30 = data[29].writeOnCloud;
  axios.post('http://localhost:4000/setw', {
    w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15, w16, w17, w18, w19, w20, w21, w22, w23, w24, w25, w26, w27, w28, w29, w30
  })
    .then(function (response) {
      console.clear();
    })
    .catch(function (error) {
      console.log(error);
    });
}, 1450);


// Application.CalculateFullRebuild

// Sub macro_timer()
// 'Tells Excel when to next run the macro.
// Application.OnTime Now + TimeValue("00:00:01"), "my_macro"
// End Sub
// Sub my_macro()
// Application.CalculateFullRebuild
// 'Calls the timer macro so it can be run again at the next interval.
// Call macro_timer

// End Sub