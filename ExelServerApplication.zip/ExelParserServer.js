const express = require('express')
const app = express()
const port = 4000
const mongoose = require('mongoose');
const exelFiles = require('./exelFileModel');
var bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(bodyParser.raw());
const idFiles = "1"
main().catch(err => console.log(err));

async function main() {
    await mongoose.connect('mongodb://localhost:27017/exelFilesDB');
}


app.post('/setw', (req, res) => {
  res.setHeader('Content-Type', 'text/plain');
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      exel.w1 =req.body.w1
      exel.w2 =req.body.w2
      exel.w3 =req.body.w3
      exel.w4 =req.body.w4
      exel.w5 =req.body.w5
      exel.w6 =req.body.w6
      exel.w7 =req.body.w7
      exel.w8 =req.body.w8
      exel.w9 =req.body.w9
      exel.w10 =req.body.w10
      exel.w11 =req.body.w11
      exel.w12 =req.body.w12
      exel.w13 =req.body.w13
      exel.w14 =req.body.w14
      exel.w15 =req.body.w15
      exel.w16 =req.body.w16
      exel.w17 =req.body.w17
      exel.w18 =req.body.w18
      exel.w19 =req.body.w19
      exel.w20 =req.body.w20
      exel.w21 =req.body.w21
      exel.w22 =req.body.w22
      exel.w23 =req.body.w23
      exel.w24 =req.body.w24
      exel.w25 =req.body.w25
      exel.w26 =req.body.w26
      exel.w27 =req.body.w27
      exel.w28 =req.body.w28
      exel.w29 =req.body.w29
      exel.w30 =req.body.w30
      exel.save(function (err) {
        if (err) {
            res.send('Err on save.');
        }
        res.send('saved');
    });
    }
  })
})


app.post('/setR', (req, res) => {
  res.setHeader('Content-Type', 'text/plain');
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      exel.r1 =req.body.r1
      exel.r2 =req.body.r2
      exel.r3 =req.body.r3
      exel.r4 =req.body.r4
      exel.r5 =req.body.r5
      exel.r6 =req.body.r6
      exel.r7 =req.body.r7
      exel.r8 =req.body.r8
      exel.r9 =req.body.r9
      exel.w10 =req.body.r10
      exel.r11 =req.body.r11
      exel.r12 =req.body.r12
      exel.r13 =req.body.r13
      exel.r14 =req.body.r14
      exel.r15 =req.body.r15
      exel.r16 =req.body.r16
      exel.r17 =req.body.r17
      exel.r18 =req.body.r18
      exel.r19 =req.body.r19
      exel.r20 =req.body.r20
      exel.r21 =req.body.r21
      exel.r22 =req.body.r22
      exel.r23 =req.body.r23
      exel.r24 =req.body.r24
      exel.r25 =req.body.r25
      exel.r26 =req.body.r26
      exel.r27 =req.body.r27
      exel.r28 =req.body.r28
      exel.r29 =req.body.r29
      exel.r30 =req.body.r30
      exel.save(function (err) {
        if (err) {
            res.send('Err on save.');
        }
        res.send('saved');
    });
    }
  })
})

app.get('/r1', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r1)
    }
  })
})

app.get('/r2', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r2)
    }
  })
})
app.get('/r3', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r3)
    }
  })
})
app.get('/r4', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r4)
    }
  })
})
app.get('/r5', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r5)
    }
  })
})
app.get('/r6', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r6)
    }
  })
})
app.get('/r7', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r7)
    }
  })
})
app.get('/r8', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r8)
    }
  })
})
app.get('/r9', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r9)
    }
  })
})
app.get('/r10', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r10)
    }
  })
})
app.get('/r11', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r11)
    }
  })
})
app.get('/r12', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r12)
    }
  })
})
app.get('/r13', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r13)
    }
  })
})
app.get('/r14', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r14)
    }
  })
})
app.get('/r15', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r15)
    }
  })
})
app.get('/r16', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r16)
    }
  })
})
app.get('/r17', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r17)
    }
  })
})
app.get('/r18', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r18)
    }
  })
})
app.get('/r19', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r19)
    }
  })
})
app.get('/r20', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r20)
    }
  })
})
app.get('/r21', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r21)
    }
  })
})
app.get('/r22', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r22)
    }
  })
})
app.get('/r23', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r23)
    }
  })
})
app.get('/r24', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r24)
    }
  })
})
app.get('/r25', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r25)
    }
  })
})
app.get('/r26', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r26)
    }
  })
})
app.get('/r27', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r27)
    }
  })
})
app.get('/r28', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r28)
    }
  })
})
app.get('/r29', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r29)
    }
  })
})
app.get('/r30', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.r30)
    }
  })
})

app.get('/w1', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w1)
    }
  })
})
app.get('/w2', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w2)
    }
  })
})
app.get('/w3', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w3)
    }
  })
})
app.get('/w4', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w4)
    }
  })
})
app.get('/w5', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w5)
    }
  })
})
app.get('/w6', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w6)
    }
  })
})
app.get('/w7', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w7)
    }
  })
})
app.get('/w8', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w8)
    }
  })
})
app.get('/w9', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w9)
    }
  })
})
app.get('/w10', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w10)
    }
  })
})
app.get('/w11', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w11)
    }
  })
})
app.get('/w12', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w12)
    }
  })
})
app.get('/w13', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w13)
    }
  })
})
app.get('/w14', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w14)
    }
  })
})
app.get('/w15', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w15)
    }
  })
})
app.get('/w16', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w16)
    }
  })
})
app.get('/w17', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w17)
    }
  })
})
app.get('/w18', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w18)
    }
  })
})
app.get('/w19', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w19)
    }
  })
})
app.get('/w20', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w20)
    }
  })
})
app.get('/w21', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w21)
    }
  })
})
app.get('/w22', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w22)
    }
  })
})
app.get('/w23', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w23)
    }
  })
})
app.get('/w24', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w24)
    }
  })
})
app.get('/w25', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w25)
    }
  })
})
app.get('/w26', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w26)
    }
  })
})
app.get('/w27', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w27)
    }
  })
})
app.get('/w28', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w28)
    }
  })
})
app.get('/w29', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w29)
    }
  })
})
app.get('/w30', (req, res) => {
  exelFiles.findOne({ idFiles : idFiles }, function (err, exel) {
    if (err) {
      res.send('error on server');
    }
    else {
      res.json(exel.w30)
    }
  })
})


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
